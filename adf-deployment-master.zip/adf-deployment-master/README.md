# adf-deployment
Azure-Data-Factory-Patterns-and-Best-practices
